#!/usr/bin/env bash
# One-command setup + start. Run:  bash setup.sh
# It asks a few questions the first time, writes .env, creates your admin account, and starts the server.
cd "$(dirname "$0")" || exit 1

# 1) Node 22.13+
need_node() { node -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>22||(a===22&&b>=13)?0:1)' 2>/dev/null; }
if ! need_node; then
  [ -s "$HOME/.nvm/nvm.sh" ] && . "$HOME/.nvm/nvm.sh" && nvm install 22 >/dev/null && nvm use 22 >/dev/null
fi
need_node || { echo "Node.js 22.13+ is required (https://nodejs.org). Current: $(node -v 2>/dev/null || echo none)"; exit 1; }

# 2) First run: ask questions, write .env
if [ ! -f .env ]; then
  echo "=== First-time setup (answers are saved in .env) ==="
  read -r -p "Your email (becomes the admin account): " AEMAIL
  read -r -p "Admin username (letters/numbers, e.g. boss): " AUSER
  read -r -s -p "Admin password (8+ chars with a letter and a number): " APASS; echo
  read -r -p "Resend API key for e-mail (press Enter to skip): " RKEY
  {
    echo "ADMIN_EMAIL=$AEMAIL"; echo "ADMIN_USERNAME=$AUSER"; echo "ADMIN_PASSWORD=$APASS"
    echo "MEETING_BASE_URL=https://meet.jit.si"
    [ -n "$RKEY" ] && { echo "RESEND_API_KEY=$RKEY"; echo "MAIL_FROM=FriendSpace <onboarding@resend.dev>"; }
  } > .env
  chmod 600 .env
fi
set -a; . ./.env; set +a

# 3) Public address + HTTPS settings (auto-detected inside GitHub Codespaces)
export NODE_ENV=production DATA_DIR="${DATA_DIR:-$PWD/data}" HOST=0.0.0.0 PORT="${PORT:-3000}"
if [ -n "$CODESPACE_NAME" ]; then
  export PUBLIC_URL="https://${CODESPACE_NAME}-${PORT}.${GITHUB_CODESPACES_PORT_FORWARDING_DOMAIN:-app.github.dev}"
  export TRUST_PROXY=1 COOKIE_SECURE=1
  command -v gh >/dev/null && gh codespace ports visibility "${PORT}:public" -c "$CODESPACE_NAME" >/dev/null 2>&1 \
    && echo "Port ${PORT} set to public." || echo "NOTE: set port ${PORT} to Public manually (Ports tab → right-click → Port Visibility → Public)."
fi
export PUBLIC_URL="${PUBLIC_URL:-http://localhost:$PORT}"

# 4) Admin account (create or refresh)
if [ -n "$ADMIN_EMAIL" ] && [ -n "$ADMIN_USERNAME" ] && [ -n "$ADMIN_PASSWORD" ]; then
  node --disable-warning=ExperimentalWarning tools/create-admin.js "$ADMIN_EMAIL" "$ADMIN_USERNAME" "$ADMIN_PASSWORD" "$ADMIN_USERNAME" || exit 1
fi

echo; echo "=============================================="
echo " App link (open on ALL your devices):"; echo "   $PUBLIC_URL"
echo " Admin panel:  $PUBLIC_URL/admin.html"
echo " Video meetings: ${MEETING_BASE_URL:-off} | E-mail: $([ -n "$RESEND_API_KEY" ] && echo Resend || echo 'saved to data/outbox (no key)')"
echo "=============================================="
exec node --disable-warning=ExperimentalWarning server/index.js
