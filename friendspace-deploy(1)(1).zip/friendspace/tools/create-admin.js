#!/usr/bin/env node
// Creates (or promotes / resets the password of) a private admin account directly in the database.
// Usage: node tools/create-admin.js you@example.com yourusername "YourStrongPassword" ["Display Name"]
// DATA_DIR defaults to ./data. Run it on the server, then sign in at /admin.html.
const path = require('node:path');
const db = require('../server/db.js').open(path.join(process.env.DATA_DIR || path.join(__dirname, '..', 'data'), 'friendspace.db'));
const U = require('../server/util.js');
(async () => {
  const [email, username, password, name] = process.argv.slice(2);
  if (!email || !username || !password) { console.error('Usage: node tools/create-admin.js <email> <username> <password> [display name]'); process.exit(1); }
  if (!/^[a-z0-9_.]{3,24}$/.test(username)) { console.error('username: 3-24 chars, a-z 0-9 _ .'); process.exit(1); }
  if (password.length < 8 || !/[a-zA-Z]/.test(password) || !/\d/.test(password)) { console.error('password: 8+ characters with a letter and a digit'); process.exit(1); }
  const hash = await U.hashPassword(password); const e = email.trim().toLowerCase();
  const ex = db.prepare('SELECT id FROM users WHERE email=? OR username=?').get(e, username);
  if (ex) { db.prepare("UPDATE users SET role='admin', disabled=0, deleted=0, password_hash=?, email=?, username=?, suspended_until=NULL WHERE id=?").run(hash, e, username, ex.id); console.log(`Updated existing user #${ex.id} -> admin, password reset.`); }
  else { const r = db.prepare("INSERT INTO users(email,username,display_name,password_hash,role,created_at) VALUES(?,?,?,?,'admin',?)").run(e, username, name || username, hash, Date.now()); console.log(`Created admin #${r.lastInsertRowid} (${e}).`); }
  console.log('Sign in at /admin.html');
})();
