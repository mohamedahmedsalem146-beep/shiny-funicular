import { h, icon, avatar, btn, modal, toast, clear, debounce, fmtDateTime } from './util.js';
import { t } from './i18n.js';
import { S, api, errText, hooks, uploadFile, cacheUser, convTitle, convAvatarSrc } from './state.js';

const field = (label, input, hint) => h('label', { class: 'field' }, h('span', null, label), input, hint ? h('small', null, hint) : null);
const input = (props) => h('input', { class: 'input', ...props });

export function reportDialog(type, id) {
  const sel = h('select', { class: 'input' }, ['spam', 'abuse', 'harassment', 'inappropriate', 'other'].map((k) => h('option', { value: k }, t('reason.' + k))));
  const det = h('textarea', { class: 'input', rows: 3, maxlength: 400, placeholder: t('report_details') });
  const m = modal(t(type === 'user' ? 'report_user' : 'report_msg'), [h('p', { class: 'muted' }, t('report_note')), field(t('reason'), sel), field(t('details'), det)], {
    actions: [btn(t('cancel'), () => m.close(), 'ghost'), btn(t('send_report'), async () => {
      try { await api('POST', '/api/reports', { type, id, reason: t('reason.' + sel.value) + (det.value.trim() ? ' — ' + det.value.trim() : '') }); toast(t('report_sent'), 'success'); m.close(); }
      catch (e) { toast(errText(e), 'error'); }
    }, 'primary')],
  });
}

function avatarPicker(initial, onPick) {
  let file = null;
  const prev = h('div', { class: 'avpick-prev' }, avatar(initial || { display_name: '?' }, 64, {}));
  const inp = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/gif,image/webp', hidden: true, onchange: async () => {
    const f = inp.files[0]; if (!f) return;
    try { file = await uploadFile(f, { purpose: 'avatar' }); const url = URL.createObjectURL(f); clear(prev).append(h('span', { class: 'av', style: { width: '64px', height: '64px' } }, h('img', { src: url, alt: '' }))); onPick(file); }
    catch (e) { toast(errText(e), 'error'); }
  } });
  return h('div', { class: 'avpick' }, prev, btn(t('choose_photo'), () => inp.click(), 'ghost', 'image'), inp);
}

export function createGroupDialog() {
  let avatarFile = null;
  const name = input({ maxlength: 60, placeholder: t('space_name'), required: true });
  const desc = h('textarea', { class: 'input', rows: 2, maxlength: 300, placeholder: t('space_desc') });
  const pub = h('input', { type: 'checkbox' });
  const picks = new Set();
  const list = h('div', { class: 'picklist' }, S.friends.length ? S.friends.map((f) => {
    const cb = h('input', { type: 'checkbox', onchange: () => (cb.checked ? picks.add(f.id) : picks.delete(f.id)) });
    return h('label', { class: 'pick' }, cb, avatar(f, 32), h('span', null, h('b', null, f.display_name), h('small', null, '@' + f.username)));
  }) : h('p', { class: 'muted' }, t('no_friends_hint')));
  const m = modal(t('new_space'), [
    avatarPicker({ display_name: '+', id: 1 }, (f) => { avatarFile = f; }),
    field(t('space_name'), name), field(t('space_desc'), desc),
    h('label', { class: 'check' }, pub, h('span', null, h('b', null, t('public_space')), h('small', null, t('public_space_hint')))),
    h('div', { class: 'field' }, h('span', null, t('add_members')), list),
  ], { actions: [btn(t('cancel'), () => m.close(), 'ghost'), btn(t('create'), async () => {
    if (!name.value.trim()) { name.focus(); return; }
    try {
      const r = await api('POST', '/api/conversations/group', { name: name.value, description: desc.value, is_public: pub.checked, member_ids: [...picks], avatar_file: avatarFile?.id });
      m.close(); hooks.afterCreate(r.conv);
    } catch (e) { toast(errText(e), 'error'); }
  }, 'primary')] });
}

export function addMembersDialog(conv, members) {
  const have = new Set(members.map((x) => x.id));
  const avail = S.friends.filter((f) => !have.has(f.id));
  const picks = new Set();
  const list = h('div', { class: 'picklist' }, avail.length ? avail.map((f) => {
    const cb = h('input', { type: 'checkbox', onchange: () => (cb.checked ? picks.add(f.id) : picks.delete(f.id)) });
    return h('label', { class: 'pick' }, cb, avatar(f, 32), h('span', null, h('b', null, f.display_name), h('small', null, '@' + f.username)));
  }) : h('p', { class: 'muted' }, t('no_more_friends')));
  const m = modal(t('add_members'), list, { actions: [btn(t('cancel'), () => m.close(), 'ghost'), btn(t('add'), async () => {
    if (!picks.size) return;
    try { await api('POST', `/api/conversations/${conv.id}/members`, { user_ids: [...picks] }); m.close(); hooks.refreshPanel(); } catch (e) { toast(errText(e), 'error'); }
  }, 'primary')] });
}

export function messageResults(list, onPick) {
  if (!list.length) return h('p', { class: 'muted pad' }, t('no_results'));
  return h('div', { class: 'results' }, list.map((m) => h('button', { class: 'result', type: 'button', onclick: () => onPick(m) },
    avatar(m.sender, 36),
    h('span', { class: 'rbody' }, h('b', null, m.conv.name || '—', h('small', null, ' · ' + m.sender.display_name + ' · ' + fmtDateTime(m.created_at))),
      h('span', { class: 'snip' }, m.file ? '📎 ' + m.file.name + (m.body ? ' — ' + m.body : '') : m.body)))));
}

export function advancedSearchDialog(pre = {}) {
  const q = input({ placeholder: t('search_messages'), value: pre.q || '', type: 'search' });
  const conv = h('select', { class: 'input' }, h('option', { value: '' }, t('all_chats')), [...S.convs.values()].map((c) => h('option', { value: c.id, selected: pre.conv == c.id }, convTitle(c))));
  const kind = h('select', { class: 'input' }, ['', 'text', 'image', 'file', 'link'].map((k) => h('option', { value: k }, t('kind.' + (k || 'any')))));
  const from = input({ type: 'date' }), to = input({ type: 'date' });
  const out = h('div', { class: 'search-out' });
  let seq = 0;
  const run = async () => {
    const my = ++seq;
    const p = new URLSearchParams({ scope: 'messages', q: q.value.trim() });
    if (conv.value) p.set('conv', conv.value); if (kind.value) p.set('kind', kind.value);
    if (from.value) p.set('from', new Date(from.value + 'T00:00:00').getTime());
    if (to.value) p.set('to', new Date(to.value + 'T00:00:00').getTime() + 864e5);
    try {
      const r = await api('GET', '/api/search?' + p);
      if (my !== seq) return;
      clear(out).append(messageResults(r.messages, (m) => { md.close(); hooks.openAround(m.conv_id, m.id); }));
    } catch (e) { toast(errText(e), 'error'); }
  };
  const go = debounce(run, 300);
  for (const el of [q, conv, kind, from, to]) el.addEventListener('input', go);
  const md = modal(t('advanced_search'), [h('div', { class: 'filters' }, q, field(t('conversation'), conv), field(t('type'), kind), field(t('from'), from), field(t('to'), to)), out], { wide: true });
  if (pre.q || pre.conv) run();
}

export function settingsDialog() {
  const me = S.me;
  const dn = input({ value: me.display_name, maxlength: 40 }), st = input({ value: me.status_text, maxlength: 80, placeholder: t('status_placeholder') });
  const avBox = h('div', { class: 'avbox' });
  const drawAv = () => clear(avBox).append(avatar(S.me, 72));
  drawAv();
  const fileIn = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/gif,image/webp', hidden: true, onchange: async () => {
    const f = fileIn.files[0]; if (!f) return;
    try { const up = await uploadFile(f, { purpose: 'avatar' }); await api('PATCH', '/api/me', { avatar_file: up.id }); drawAv(); toast(t('saved'), 'success'); } catch (e) { toast(errText(e), 'error'); }
  } });
  const saveProfile = async () => { try { await api('PATCH', '/api/me', { display_name: dn.value, status_text: st.value }); toast(t('saved'), 'success'); } catch (e) { toast(errText(e), 'error'); } };

  const seg = (opts, cur, on) => h('div', { class: 'seg' }, opts.map(([v, l]) => h('button', { type: 'button', class: v === cur ? 'on' : '', onclick: (e) => { on(v); e.currentTarget.parentElement.querySelectorAll('button').forEach((b) => b.classList.remove('on')); e.currentTarget.classList.add('on'); } }, l)));

  const notifBtn = h('button', { class: 'btn ghost', type: 'button' });
  const drawNotif = () => {
    const p = 'Notification' in window ? Notification.permission : 'unsupported';
    notifBtn.textContent = p === 'granted' ? t('notif_on') : p === 'denied' ? t('notif_blocked') : p === 'unsupported' ? t('notif_unsupported') : t('notif_enable');
    notifBtn.disabled = p !== 'default';
  };
  notifBtn.onclick = async () => { try { await Notification.requestPermission(); } catch {} drawNotif(); };
  drawNotif();

  const allow = h('input', { type: 'checkbox', checked: me.allow_requests, onchange: () => api('PATCH', '/api/me', { allow_requests: allow.checked }).catch((e) => toast(errText(e), 'error')) });
  const blockedBox = h('div', { class: 'blocked' });
  const drawBlocked = () => clear(blockedBox).append(S.blocked.length ? S.blocked.map((u) => h('div', { class: 'row' }, avatar(u, 32), h('span', null, u.display_name, h('small', null, ' @' + u.username)), btn(t('unblock'), async () => { await api('DELETE', `/api/blocks/${u.id}`).catch((e) => toast(errText(e), 'error')); setTimeout(drawBlocked, 250); }, 'ghost small'))) : h('p', { class: 'muted' }, t('no_blocked')));
  drawBlocked();

  const cur = input({ type: 'password', autocomplete: 'current-password' }), nw = input({ type: 'password', autocomplete: 'new-password' });
  const section = (title, ...kids) => h('section', { class: 'sect' }, h('h3', null, title), kids);

  const md = modal(t('settings'), [
    section(t('profile'), h('div', { class: 'profile-row' }, avBox, h('div', null, btn(t('change_photo'), () => fileIn.click(), 'ghost small', 'image'), btn(t('remove_photo'), async () => { await api('PATCH', '/api/me', { avatar_file: null }); drawAv(); }, 'ghost small'), fileIn)),
      field(t('display_name'), dn), field(t('status'), st), btn(t('save'), saveProfile, 'primary')),
    section(t('appearance'), field(t('theme'), seg([['light', t('light')], ['dark', t('dark')], ['system', t('system')]], hooks.getTheme(), (v) => hooks.setTheme(v))),
      field(t('language'), seg([['ar', 'العربية'], ['en', 'English']], hooks.getLang(), (v) => { hooks.setLang(v); md.close(); }))),
    section(t('notifications'), h('p', { class: 'muted' }, t('notif_hint')), notifBtn),
    section(t('privacy'), h('label', { class: 'check' }, allow, h('span', null, h('b', null, t('allow_requests')), h('small', null, t('allow_requests_hint')))), h('h4', null, t('blocked_users')), blockedBox),
    section(t('security'), field(t('current_password'), cur), field(t('new_password'), nw, t('password_rules')),
      btn(t('change_password'), async () => { try { await api('POST', '/api/me/password', { current: cur.value, next: nw.value }); cur.value = nw.value = ''; toast(t('password_changed'), 'success'); } catch (e) { toast(errText(e), 'error'); } }, 'ghost'),
      h('div', { class: 'sp' }), btn(t('logout_all'), async () => { try { await api('POST', '/api/auth/logout-all'); } catch {} hooks.sessionLost(); }, 'danger', 'logout')),
  ], { wide: true });
  hooks.refreshBlocked = drawBlocked;
}
