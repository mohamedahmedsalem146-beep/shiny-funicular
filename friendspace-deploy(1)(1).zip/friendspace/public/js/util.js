import { icon } from './icons.js';
import { t, locale } from './i18n.js';

// Native append()/prepend() turn arrays into "[object HTMLElement]" text; accept arrays/null/false like h() does.
for (const m of ['append', 'prepend']) {
  const native = Element.prototype[m];
  Element.prototype[m] = function (...a) { return native.apply(this, a.flat(Infinity).filter((x) => x != null && x !== false)); };
}

export function h(tag, props, ...kids) {
  const el = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (v == null || v === false) continue;
    if (k === 'class') el.className = v;
    else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'dataset') Object.assign(el.dataset, v);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (v === true) el.setAttribute(k, '');
    else el.setAttribute(k, v);
  }
  add(el, kids);
  return el;
}
export function add(el, kids) {
  for (const k of kids.flat(Infinity)) {
    if (k == null || k === false) continue;
    el.append(k.nodeType ? k : document.createTextNode(String(k)));
  }
  return el;
}
export const $ = (s, r = document) => r.querySelector(s);
export const clear = (el) => { el.replaceChildren(); return el; };
export const btn = (label, onclick, cls = '', ic) => h('button', { class: 'btn ' + cls, type: 'button', onclick }, ic ? icon(ic, 18) : null, label ? h('span', null, label) : null);
export const iconBtn = (ic, label, onclick, cls = '') => h('button', { class: 'ibtn ' + cls, type: 'button', 'aria-label': label, title: label, onclick }, icon(ic, 20));

const COLORS = ['#0b7a85', '#c2410c', '#6d28d9', '#047857', '#be185d', '#1d4ed8', '#a16207', '#0e7490'];
export function avatar(u, size = 40, opts = {}) {
  const name = u?.display_name || u?.name || '?';
  const wrap = h('span', { class: 'av', style: { width: size + 'px', height: size + 'px', fontSize: Math.round(size * 0.4) + 'px' } });
  const colorId = (u?.id ?? 0) + (opts.group ? 3 : 0);
  wrap.style.background = COLORS[Math.abs(colorId) % COLORS.length];
  const initials = [...name.trim()].slice(0, 1).join('').toUpperCase() || '?';
  wrap.append(opts.group && !u?.avatar_file ? icon('users', Math.round(size * 0.5)) : initials);
  if (u?.avatar_file) {
    const img = h('img', { src: `/api/files/${u.avatar_file}`, alt: '', loading: 'lazy' });
    img.addEventListener('error', () => img.remove());
    wrap.append(img);
  }
  if (opts.dot !== undefined) wrap.append(h('i', { class: 'dot' + (opts.dot ? ' on' : '') }));
  return wrap;
}

export const fmtTime = (ts) => new Date(ts).toLocaleTimeString(locale(), { hour: '2-digit', minute: '2-digit' });
export function fmtDay(ts) {
  const d = new Date(ts), n = new Date();
  const day = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const diff = Math.round((day(n) - day(d)) / 864e5);
  if (diff === 0) return t('today'); if (diff === 1) return t('yesterday');
  return d.toLocaleDateString(locale(), { weekday: diff < 7 ? 'long' : undefined, day: 'numeric', month: 'long', year: n.getFullYear() === d.getFullYear() ? undefined : 'numeric' });
}
export function fmtListTime(ts) {
  const d = new Date(ts), n = new Date();
  if (d.toDateString() === n.toDateString()) return fmtTime(ts);
  if (n - d < 6 * 864e5) return d.toLocaleDateString(locale(), { weekday: 'short' });
  return d.toLocaleDateString(locale(), { day: 'numeric', month: 'short' });
}
export const fmtDateTime = (ts) => new Date(ts).toLocaleString(locale(), { dateStyle: 'medium', timeStyle: 'short' });
export function fmtSize(n) {
  if (n < 1024) return n + ' B'; if (n < 1048576) return (n / 1024).toFixed(1) + ' KB'; return (n / 1048576).toFixed(1) + ' MB';
}
export const sameDay = (a, b) => new Date(a).toDateString() === new Date(b).toDateString();

// ---- safe linkify: only http(s), built with DOM nodes, never innerHTML ----
const URL_RE = /https?:\/\/[^\s<>"']+/g;
export function linkify(text) {
  const frag = document.createDocumentFragment(); let last = 0; const urls = [];
  for (const m of text.matchAll(URL_RE)) {
    let url = m[0]; const trail = /[.,;:!?)\]،؛؟]+$/.exec(url);
    if (trail) url = url.slice(0, -trail[0].length);
    try { new URL(url); } catch { continue; }
    frag.append(text.slice(last, m.index));
    frag.append(h('a', { href: url, target: '_blank', rel: 'noopener noreferrer nofollow' }, url));
    urls.push(url); last = m.index + url.length;
  }
  frag.append(text.slice(last));
  return { frag, urls };
}

// ---- toasts ----
let toastBox;
export function toast(msg, kind = 'info', onclick) {
  if (!toastBox) { toastBox = h('div', { class: 'toasts', role: 'status', 'aria-live': 'polite' }); document.body.append(toastBox); }
  const el = h('div', { class: 'toast ' + kind, onclick: () => { onclick?.(); el.remove(); } }, msg);
  toastBox.append(el);
  setTimeout(() => el.remove(), kind === 'error' ? 6000 : 4000);
  while (toastBox.children.length > 4) toastBox.firstChild.remove();
}

// ---- popup menu ----
let openMenuEl;
export function closeMenu() { openMenuEl?.remove(); openMenuEl = null; document.removeEventListener('pointerdown', outside, true); document.removeEventListener('keydown', esc, true); }
const outside = (e) => { if (openMenuEl && !openMenuEl.contains(e.target)) closeMenu(); };
const esc = (e) => { if (e.key === 'Escape') closeMenu(); };
export function popup(anchor, content, cls = '') {
  closeMenu();
  const m = h('div', { class: 'popup ' + cls, role: 'menu' }, content);
  document.body.append(m); openMenuEl = m;
  const r = anchor.getBoundingClientRect(), w = m.offsetWidth, hh = m.offsetHeight;
  const rtl = document.documentElement.dir === 'rtl';
  let left = rtl ? r.left : r.right - w; left = Math.max(8, Math.min(left, innerWidth - w - 8));
  let top = r.bottom + 6; if (top + hh > innerHeight - 8) top = Math.max(8, r.top - hh - 6);
  m.style.left = left + 'px'; m.style.top = top + 'px';
  setTimeout(() => { document.addEventListener('pointerdown', outside, true); document.addEventListener('keydown', esc, true); }, 0);
  m.querySelector('button')?.focus();
  return m;
}
export function menu(anchor, items) {
  const list = items.filter(Boolean).map((i) => i.sep ? h('hr') : h('button', { class: 'mi' + (i.danger ? ' danger' : ''), role: 'menuitem', type: 'button', onclick: () => { closeMenu(); i.onClick(); } }, i.icon ? icon(i.icon, 18) : null, h('span', null, i.label)));
  return popup(anchor, list, 'menu');
}

// ---- modal ----
export function modal(title, body, { actions = [], wide = false, onClose } = {}) {
  const prev = document.activeElement;
  const close = () => { back.remove(); document.removeEventListener('keydown', onKey); prev?.focus?.(); onClose?.(); };
  const onKey = (e) => { if (e.key === 'Escape') close(); };
  const back = h('div', { class: 'modal-back', onpointerdown: (e) => { if (e.target === back) close(); } },
    h('div', { class: 'modal' + (wide ? ' wide' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
      h('header', null, h('h2', null, title), iconBtn('x', t('close'), close)),
      h('div', { class: 'modal-body' }, body),
      actions.length ? h('footer', null, actions) : null));
  document.body.append(back); document.addEventListener('keydown', onKey);
  (back.querySelector('input,textarea,select') || back.querySelector('.modal-body button'))?.focus();
  return { close, el: back };
}
export function confirmBox(title, text, okLabel, danger = true) {
  return new Promise((resolve) => {
    const m = modal(title, h('p', null, text), { onClose: () => resolve(false), actions: [
      btn(t('cancel'), () => { resolve(false); m.close(); }, 'ghost'),
      btn(okLabel, () => { resolve(true); m.close(); }, danger ? 'danger' : 'primary')] });
  });
}
export const debounce = (fn, ms) => { let tm; return (...a) => { clearTimeout(tm); tm = setTimeout(() => fn(...a), ms); }; };
export { icon };
