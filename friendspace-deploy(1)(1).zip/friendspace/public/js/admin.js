import { h, $, icon, avatar, btn, iconBtn, clear, menu, toast, confirmBox, modal, debounce, fmtDateTime } from './util.js';
import { t } from './i18n.js';
import { S, api, errText, hooks } from './state.js';

let section = 'overview';
const SECTIONS = () => [['overview', 'shield', t('a.overview')], ['users', 'users', t('a.users')], ['reports', 'flag', t('a.reports')], ['appeals', 'chat', t('a.appeals')], ['violations', 'ban', t('a.violations')], ['spaces', 'grid', t('a.spaces')], ...(S.me.role === 'admin' ? [['audit', 'file', t('a.audit')]] : [])];

export function drawAdminSide(body) {
  clear(body).append(h('div', { class: 'list' }, SECTIONS().map(([k, ic, l]) => h('div', { class: 'item static nav' + (section === k ? ' active' : ''), role: 'button', tabindex: 0, onclick: () => { section = k; drawAdminSide(body); show(); document.body.classList.add('show-chat'); }, onkeydown: (e) => e.key === 'Enter' && e.currentTarget.click() }, h('span', { class: 'navic' }, icon(ic, 20)), h('b', { class: 'name' }, l)))));
  show();
}
export function show() {
  const main = $('#main'); S.activeId = null;
  const wrap = h('section', { class: 'admin' }, h('header', { class: 'chat-head' }, iconBtn('back', t('back'), () => document.body.classList.remove('show-chat'), 'back-btn dir'), h('h2', null, SECTIONS().find((s) => s[0] === section)?.[2]), h('span', { class: 'role-chip' }, t('role.' + S.me.role))), h('div', { class: 'admin-body' }));
  clear(main).append(wrap);
  const body = wrap.querySelector('.admin-body');
  ({ overview, users, reports, appeals, violations, spaces, audit })[section](body);
}

async function overview(body) {
  try {
    const s = await api('GET', '/api/admin/stats');
    body.append(h('div', { class: 'stats' }, [['users', s.users], ['online_now', s.online], ['disabled', s.disabled], ['suspended', s.suspended], ['open_appeals', s.open_appeals], ['groups', s.groups], ['messages', s.messages], ['open_reports', s.open_reports]].map(([k, v]) => h('div', { class: 'stat' + ((k === 'open_reports' || k === 'open_appeals') && v ? ' alert' : '') }, h('b', null, v), h('span', null, t('s.' + k))))),
      h('p', { class: 'muted pad' }, t('admin_privacy_note')));
  } catch (e) { body.append(h('p', { class: 'muted' }, errText(e))); }
}

function users(body) {
  const q = h('input', { class: 'input', type: 'search', placeholder: t('search_users') });
  const table = h('div', { class: 'tbl-wrap' });
  const load = async () => {
    try {
      const r = await api('GET', '/api/admin/users?q=' + encodeURIComponent(q.value));
      clear(table).append(h('table', { class: 'tbl' }, h('thead', null, h('tr', null, [t('user'), S.me.role === 'admin' ? t('email') : null, t('role_l'), t('joined'), t('status_l'), ''].map((x) => x === null ? null : h('th', null, x)))),
        h('tbody', null, r.users.map((u) => h('tr', { class: u.disabled ? 'dis' : '' },
          h('td', null, h('div', { class: 'ucell' }, avatar(u, 32, { dot: u.online }), h('span', null, h('b', null, u.display_name), h('small', null, '@' + u.username)))),
          S.me.role === 'admin' ? h('td', { dir: 'ltr' }, u.email) : null,
          h('td', null, h('span', { class: 'role ' + u.role }, t('role.' + u.role))),
          h('td', null, new Date(u.created_at).toLocaleDateString(document.documentElement.lang)),
          h('td', null, u.disabled ? h('span', { class: 'tag bad' }, t('disabled')) : u.suspended_until ? h('span', { class: 'tag bad', title: fmtDateTime(u.suspended_until) }, t('suspended')) : u.online ? h('span', { class: 'tag ok' }, t('online')) : h('span', { class: 'tag' }, t('offline'))),
          h('td', null, u.id !== S.me.id && (S.me.role === 'admin' || u.role === 'user') ? iconBtn('more', t('more'), (e) => menu(e.currentTarget, [
            { label: u.disabled ? t('enable_account') : t('disable_account'), icon: 'ban', danger: !u.disabled, onClick: async () => { if (u.disabled || await confirmBox(t('disable_account'), t('disable_text', { n: u.display_name }), t('disable_account'))) { await api('PATCH', `/api/admin/users/${u.id}`, { disabled: !u.disabled }).catch((x) => toast(errText(x), 'error')); load(); } } },
            u.suspended_until ? { label: t('lift_suspension'), icon: 'check', onClick: async () => { await api('POST', `/api/admin/users/${u.id}/lift-suspension`).catch((x) => toast(errText(x), 'error')); load(); } } : null,
            S.me.role === 'admin' ? { label: t('change_role'), icon: 'shield', onClick: () => roleDialog(u, load) } : null,
            S.me.role === 'admin' ? { label: t('gen_reset'), icon: 'lock', onClick: async () => { try { const r = await api('POST', `/api/admin/users/${u.id}/reset-link`); modal(t('gen_reset'), [h('p', null, t('reset_link_hint')), h('input', { class: 'input', readonly: true, dir: 'ltr', value: r.link, onfocus: (ev) => ev.target.select() })]); } catch (x) { toast(errText(x), 'error'); } } } : null,
            S.me.role === 'admin' ? { sep: true } : null,
            S.me.role === 'admin' ? { label: t('delete_account'), icon: 'trash', danger: true, onClick: async () => { if (await confirmBox(t('delete_account'), t('delete_account_text', { n: u.display_name }), t('delete'))) { await api('DELETE', `/api/admin/users/${u.id}`).catch((x) => toast(errText(x), 'error')); load(); } } } : null])) : null))))));
    } catch (e) { clear(table).append(h('p', { class: 'muted pad' }, errText(e))); }
  };
  q.addEventListener('input', debounce(load, 250));
  body.append(h('div', { class: 'pad' }, q), table); load();
}
function roleDialog(u, done) {
  const sel = h('select', { class: 'input' }, ['user', 'moderator', 'admin'].map((r) => h('option', { value: r, selected: u.role === r }, t('role.' + r))));
  const m = modal(t('change_role'), [h('p', { class: 'muted' }, t('role_hint')), sel], { actions: [btn(t('cancel'), () => m.close(), 'ghost'), btn(t('save'), async () => { try { await api('PATCH', `/api/admin/users/${u.id}`, { role: sel.value }); m.close(); done(); } catch (e) { toast(errText(e), 'error'); } }, 'primary')] });
}

function reports(body) {
  let status = 'open';
  const list = h('div', { class: 'cards' });
  const seg = h('div', { class: 'seg pad' }, ['open', 'resolved', 'dismissed'].map((k) => h('button', { type: 'button', class: k === status ? 'on' : '', onclick: (e) => { status = k; seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === e.currentTarget)); load(); } }, t('rs.' + k))));
  const act = async (r, body2) => { try { await api('PATCH', `/api/admin/reports/${r.id}`, body2); toast(t('saved'), 'success'); load(); } catch (e) { toast(errText(e), 'error'); } };
  const load = async () => {
    try {
      const r = await api('GET', '/api/admin/reports?status=' + status);
      clear(list).append(r.reports.length ? r.reports.map((x) => h('article', { class: 'card' },
        h('header', null, h('b', null, t(x.target_type === 'message' ? 'report_msg' : 'report_user')), h('small', null, ' · ' + t('by') + ' @' + x.reporter_name + ' · ' + fmtDateTime(x.created_at))),
        h('p', { class: 'reason' }, x.reason),
        x.target_type === 'message' ? h('blockquote', { dir: 'auto' }, x.snapshot.body || (x.snapshot.file ? '📎 ' + x.snapshot.file : '—'), x.target_user ? h('small', null, ' — ' + x.target_user.display_name + ' @' + x.target_user.username) : null)
          : h('p', null, x.target_user ? x.target_user.display_name + ' @' + x.target_user.username : ''),
        x.status === 'open' ? h('footer', null,
          x.target_type === 'message' ? btn(t('act_delete_msg'), () => act(x, { status: 'resolved', action: 'delete_message' }), 'danger small', 'trash') : null,
          btn(t('act_disable_user'), () => act(x, { status: 'resolved', action: 'disable_user' }), 'ghost danger-text small', 'ban'),
          btn(t('act_resolve'), () => act(x, { status: 'resolved' }), 'primary small', 'check'),
          btn(t('act_dismiss'), () => act(x, { status: 'dismissed' }), 'ghost small')) : h('small', { class: 'muted' }, t('rs.' + x.status) + ' · ' + fmtDateTime(x.handled_at)))) : h('p', { class: 'muted pad' }, t('no_reports')));
    } catch (e) { clear(list).append(h('p', { class: 'muted pad' }, errText(e))); }
  };
  body.append(seg, list); load();
}

async function spaces(body) {
  try {
    const r = await api('GET', '/api/admin/spaces');
    body.append(r.spaces.length ? h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', null, h('tr', null, [t('name'), t('owner'), t('members'), t('created'), ''].map((x) => h('th', null, x)))),
      h('tbody', null, r.spaces.map((s) => h('tr', null, h('td', null, h('b', null, s.name), h('small', { class: 'blk' }, s.description)), h('td', null, s.owner || '—'), h('td', null, s.member_count), h('td', null, new Date(s.created_at).toLocaleDateString(document.documentElement.lang)),
        h('td', null, S.me.role === 'admin' ? iconBtn('trash', t('delete_space'), async () => { if (await confirmBox(t('delete_space'), t('delete_space_text'), t('delete'))) { await api('DELETE', `/api/admin/spaces/${s.id}`).catch((x) => toast(errText(x), 'error')); clear(body); spaces(body); } }, 'bad') : null)))))) : h('p', { class: 'muted pad' }, t('no_public_spaces')));
  } catch (e) { body.append(h('p', { class: 'muted' }, errText(e))); }
}
async function audit(body) {
  try {
    const r = await api('GET', '/api/admin/audit');
    body.append(r.audit.length ? h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', null, h('tr', null, [t('when'), t('actor'), t('action'), t('target'), t('detail')].map((x) => h('th', null, x)))),
      h('tbody', null, r.audit.map((a) => h('tr', null, h('td', null, fmtDateTime(a.created_at)), h('td', null, a.actor_name ? '@' + a.actor_name : '—'), h('td', null, h('code', null, a.action)), h('td', null, a.target || ''), h('td', null, a.detail || '')))))) : h('p', { class: 'muted pad' }, t('no_audit')));
  } catch (e) { body.append(h('p', { class: 'muted' }, errText(e))); }
}

function appeals(body) {
  let status = 'open';
  const list = h('div', { class: 'cards' });
  const seg = h('div', { class: 'seg pad' }, ['open', 'accepted', 'rejected'].map((k) => h('button', { type: 'button', class: k === status ? 'on' : '', onclick: (e) => { status = k; seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === e.currentTarget)); load(); } }, t('as.' + k))));
  const load = async () => {
    try {
      const r = await api('GET', '/api/admin/appeals?status=' + status);
      clear(list).append(r.appeals.length ? r.appeals.map((a) => {
        const resp = h('input', { class: 'input', placeholder: t('response_ph'), maxlength: 500 });
        const decide = async (d) => { try { await api('PATCH', `/api/admin/appeals/${a.id}`, { decision: d, response: resp.value }); toast(t('saved'), 'success'); load(); } catch (e) { toast(errText(e), 'error'); } };
        return h('article', { class: 'card' },
          h('header', null, h('b', null, a.display_name), h('small', null, ' @' + a.username + ' · ' + fmtDateTime(a.created_at))),
          h('p', null, h('small', { class: 'muted' }, t('viol.' + a.category) + ' · ' + t('ctx.' + a.context) + ' · ' + t('term') + ': ' + a.term + ' · ' + t('suspension_ends') + ': ' + fmtDateTime(a.suspended_until))),
          h('small', { class: 'muted' }, t('violation_text')), h('blockquote', { dir: 'auto' }, a.vtext),
          h('small', { class: 'muted' }, t('user_appeal')), h('blockquote', { dir: 'auto' }, a.text),
          a.status === 'open' ? h('footer', { class: 'col' }, resp, h('div', { class: 'row' }, btn(t('act_accept'), () => decide('accept'), 'primary small', 'check'), btn(t('act_reject'), () => decide('reject'), 'ghost danger-text small', 'x')))
            : h('p', null, a.response ? h('span', null, h('b', null, t('susp.response') + ': '), a.response) : null, h('small', { class: 'muted' }, ' · ' + fmtDateTime(a.handled_at))));
      }) : h('p', { class: 'muted pad' }, t('no_appeals')));
    } catch (e) { clear(list).append(h('p', { class: 'muted pad' }, errText(e))); }
  };
  body.append(seg, list); load();
}
async function violations(body) {
  try {
    const r = await api('GET', '/api/admin/violations');
    body.append(r.violations.length ? h('div', { class: 'tbl-wrap' }, h('table', { class: 'tbl' }, h('thead', null, h('tr', null, [t('when'), t('user'), t('category'), t('context'), t('violation_text'), t('status_l')].map((x) => h('th', null, x)))),
      h('tbody', null, r.violations.map((v) => h('tr', null, h('td', null, fmtDateTime(v.created_at)), h('td', null, '@' + v.username), h('td', null, t('viol.' + v.category)), h('td', null, t('ctx.' + v.context)), h('td', { dir: 'auto' }, v.text.slice(0, 80)),
        h('td', null, h('span', { class: 'tag' }, t('vs.' + v.status)), v.appeal_status ? h('span', { class: 'tag' }, t('as.' + v.appeal_status)) : null)))))) : h('p', { class: 'muted pad' }, t('no_violations')));
  } catch (e) { body.append(h('p', { class: 'muted' }, errText(e))); }
}
