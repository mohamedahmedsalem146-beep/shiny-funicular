import { h, $, icon, avatar, iconBtn, btn, clear, menu, toast, confirmBox, debounce, fmtListTime } from './util.js';
import { t } from './i18n.js';
import { S, api, errText, hooks, convTitle, convAvatarSrc, sortedConvs, previewText, cacheUser } from './state.js';
import { createGroupDialog, messageResults, advancedSearchDialog, reportDialog } from './dialogs.js';

let spaceQuery = '';
export function renderSide() {
  const side = $('#side'); if (!side) return;
  const body = $('#sidebody'), title = $('#sidetitle'), act = $('#sideact');
  for (const b of document.querySelectorAll('.rail [data-tab]')) b.classList.toggle('on', b.dataset.tab === S.tab);
  const badge = document.querySelector('.rail [data-tab="chats"] .badge');
  let n = 0; for (const c of S.convs.values()) if (!c.my.muted && !c.my.archived) n += c.unread;
  const pend = S.incoming.length;
  badge.textContent = n > 99 ? '99+' : n; badge.hidden = !n;
  const cb = document.querySelector('.rail [data-tab="contacts"] .badge'); cb.textContent = pend; cb.hidden = !pend;
  clear(act);
  const scroll = body.scrollTop;
  if (S.tab === 'chats') { title.textContent = t('chats'); act.append(iconBtn('plus', t('new_space'), createGroupDialog)); drawChats(body); }
  else if (S.tab === 'contacts') { title.textContent = t('contacts'); drawContacts(body); }
  else if (S.tab === 'spaces') { title.textContent = t('spaces'); act.append(iconBtn('plus', t('new_space'), createGroupDialog)); drawSpaces(body); }
  else if (S.tab === 'admin') { title.textContent = t('admin'); hooks.drawAdminSide(body); }
  body.scrollTop = scroll;
}

function convItem(c) {
  const dm = c.type === 'dm';
  const active = c.id === S.activeId;
  const el = h('div', { class: 'item' + (active ? ' active' : ''), role: 'button', tabindex: 0, 'aria-current': active ? 'true' : null, onclick: () => hooks.open(c.id), onkeydown: (e) => { if (e.key === 'Enter') hooks.open(c.id); } },
    avatar(convAvatarSrc(c), 46, dm ? { dot: S.online.has(c.peer.id) } : { group: true }),
    h('div', { class: 'item-main' },
      h('div', { class: 'item-top' }, h('b', { class: 'name' }, convTitle(c)), c.my.pinned ? icon('pin', 13, 'mini') : null, c.my.muted ? icon('bellOff', 13, 'mini') : null, h('time', null, c.last_message ? fmtListTime(c.last_message.created_at) : '')),
      h('div', { class: 'item-bot' }, h('span', { class: 'preview', dir: 'auto' }, previewText(c.last_message, c)), c.unread ? h('span', { class: 'ubadge' + (c.my.muted ? ' muted' : '') }, c.unread > 99 ? '99+' : c.unread) : null)),
    iconBtn('more', t('more'), (e) => { e.stopPropagation(); menu(e.currentTarget, [
      { label: c.my.pinned ? t('unpin_chat') : t('pin_chat'), icon: 'pin', onClick: () => patch(c, { pinned: !c.my.pinned }) },
      { label: c.my.muted ? t('unmute') : t('mute'), icon: c.my.muted ? 'bell' : 'bellOff', onClick: () => patch(c, { muted: !c.my.muted }) },
      { label: c.my.archived ? t('unarchive') : t('archive'), icon: 'archive', onClick: () => patch(c, { archived: !c.my.archived }) }]); }, 'item-more'));
  return el;
}
async function patch(c, p) { try { await api('PATCH', `/api/conversations/${c.id}/me`, p); } catch (e) { toast(errText(e), 'error'); } }

function drawChats(body) {
  const all = sortedConvs();
  const archivedCount = all.filter((c) => c.my.archived).length;
  const unreadCount = all.filter((c) => c.unread && !c.my.archived).length;
  const chips = h('div', { class: 'chips' }, [['all', t('all')], ['unread', t('unread') + (unreadCount ? ` (${unreadCount})` : '')], ['groups', t('groups')], ['archived', t('archived') + (archivedCount ? ` (${archivedCount})` : '')]].map(([k, l]) => h('button', { type: 'button', class: 'chip' + (S.filter === k ? ' on' : ''), onclick: () => { S.filter = k; renderSide(); } }, l)));
  let list = all.filter((c) => (S.filter === 'archived' ? c.my.archived : !c.my.archived));
  if (S.filter === 'unread') list = list.filter((c) => c.unread); if (S.filter === 'groups') list = list.filter((c) => c.type === 'group');
  clear(body).append(chips, list.length ? h('div', { class: 'list' }, list.map(convItem))
    : h('div', { class: 'empty-list' }, icon('chat', 32), h('p', null, S.filter === 'all' && !all.length ? t('no_chats') : t('nothing_here')), S.filter === 'all' && !all.length ? btn(t('find_friends'), () => { S.tab = 'contacts'; renderSide(); }, 'primary') : null));
}

function userRow(u, ...actions) {
  return h('div', { class: 'item static' }, avatar(u, 42, { dot: S.online.has(u.id) }), h('div', { class: 'item-main' }, h('b', { class: 'name' }, u.display_name), h('span', { class: 'preview' }, '@' + u.username + (u.status_text ? ' · ' + u.status_text : ''))), h('div', { class: 'row-actions' }, actions));
}

function drawContacts(body) {
  const inp = h('input', { class: 'input', placeholder: t('friend_username'), 'aria-label': t('friend_username'), autocapitalize: 'none', spellcheck: 'false', maxlength: 30 });
  const add = async () => {
    const v = inp.value.trim(); if (!v) return;
    try { const r = await api('POST', '/api/friends/request', { username: v }); inp.value = ''; toast(t(r.status === 'accepted' ? 'now_friends' : 'request_sent'), 'success'); } catch (e) { toast(errText(e), 'error'); }
  };
  inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') add(); });
  clear(body).append(h('div', { class: 'addfriend' }, h('label', null, t('add_friend')), h('div', { class: 'row' }, inp, btn(t('add'), add, 'primary', 'userPlus'))));
  if (S.incoming.length) body.append(h('h4', { class: 'sec' }, t('requests') + ` (${S.incoming.length})`), ...S.incoming.map((r) => userRow(r.user,
    iconBtn('check', t('accept'), () => api('POST', `/api/friends/${r.id}/accept`).catch((e) => toast(errText(e), 'error')), 'ok'),
    iconBtn('x', t('decline'), () => api('POST', `/api/friends/${r.id}/decline`).catch((e) => toast(errText(e), 'error')), 'bad'))));
  if (S.outgoing.length) body.append(h('h4', { class: 'sec' }, t('sent_requests')), ...S.outgoing.map((r) => userRow(r.user, btn(t('cancel'), () => api('POST', `/api/friends/${r.id}/decline`).catch((e) => toast(errText(e), 'error')), 'ghost small'))));
  body.append(h('h4', { class: 'sec' }, t('friends') + ` (${S.friends.length})`));
  if (!S.friends.length) body.append(h('p', { class: 'muted pad' }, t('no_friends_hint')));
  const sorted = [...S.friends].sort((a, b) => (S.online.has(b.id) - S.online.has(a.id)) || a.display_name.localeCompare(b.display_name));
  for (const f of sorted) {
    const row = userRow(f, iconBtn('chat', t('message'), () => hooks.openDm(f.id)), iconBtn('more', t('more'), (e) => menu(e.currentTarget, [
      { label: t('message'), icon: 'chat', onClick: () => hooks.openDm(f.id) },
      { label: t('unfriend'), icon: 'user', onClick: async () => { if (await confirmBox(t('unfriend'), t('unfriend_text', { n: f.display_name }), t('unfriend'))) api('DELETE', `/api/friends/${f.id}`).catch((x) => toast(errText(x), 'error')); } },
      { label: t('block'), icon: 'ban', danger: true, onClick: async () => { if (await confirmBox(t('block'), t('block_text', { n: f.display_name }), t('block'))) api('POST', '/api/blocks', { user_id: f.id }).catch((x) => toast(errText(x), 'error')); } },
      { label: t('report_user'), icon: 'flag', danger: true, onClick: () => reportDialog('user', f.id) }])));
    row.addEventListener('dblclick', () => hooks.openDm(f.id));
    body.append(row);
  }
}

function drawSpaces(body) {
  const mine = sortedConvs().filter((c) => c.type === 'group');
  clear(body).append(h('h4', { class: 'sec' }, t('my_spaces')));
  if (!mine.length) body.append(h('p', { class: 'muted pad' }, t('no_spaces')), h('div', { class: 'pad' }, btn(t('new_space'), createGroupDialog, 'primary', 'plus')));
  else body.append(h('div', { class: 'list' }, mine.map(convItem)));
  const q = h('input', { class: 'input', type: 'search', placeholder: t('discover_spaces'), value: spaceQuery, 'aria-label': t('discover_spaces') });
  const res = h('div', { class: 'list' });
  const run = async () => {
    spaceQuery = q.value;
    try {
      const r = await api('GET', '/api/spaces/public?q=' + encodeURIComponent(q.value));
      clear(res).append(r.spaces.length ? r.spaces.map((s) => h('div', { class: 'item static' }, avatar({ id: s.id, display_name: s.name, avatar_file: s.avatar_file }, 42, { group: true }), h('div', { class: 'item-main' }, h('b', { class: 'name' }, s.name), h('span', { class: 'preview' }, s.description || t('n_members', { n: s.member_count }))), btn(t('join'), async () => { try { const j = await api('POST', `/api/conversations/${s.id}/join`); hooks.afterCreate(j.conv); } catch (e) { toast(errText(e), 'error'); } }, 'primary small'))) : h('p', { class: 'muted pad' }, t('no_public_spaces')));
    } catch {}
  };
  q.addEventListener('input', debounce(run, 250));
  body.append(h('h4', { class: 'sec' }, t('discover')), h('div', { class: 'pad' }, q), res); run();
}

// ---------- global search (top bar) ----------
export function mountSearch(host) {
  const input = h('input', { type: 'search', class: 'gsearch-in', placeholder: t('search_ph'), 'aria-label': t('search'), autocomplete: 'off', maxlength: 100 });
  const drop = h('div', { class: 'gsearch-drop', hidden: true });
  const box = h('div', { class: 'gsearch' }, icon('search', 18), input, drop);
  let seq = 0;
  const close = () => { drop.hidden = true; };
  const run = async () => {
    const q = input.value.trim(); const my = ++seq;
    if (q.length < 2) { close(); return; }
    try {
      const r = await api('GET', '/api/search?scope=all&q=' + encodeURIComponent(q));
      if (my !== seq) return;
      clear(drop);
      if (r.people.length) drop.append(h('h5', null, t('people')), ...r.people.map((u) => h('div', { class: 'srow' }, avatar(u, 34), h('span', { class: 'mi-name' }, h('b', null, u.display_name), h('small', null, '@' + u.username)),
        u.relation === 'friend' ? btn(t('message'), () => { close(); input.value = ''; hooks.openDm(u.id); }, 'ghost small')
          : u.relation === 'none' ? btn(t('add'), async () => { try { await api('POST', '/api/friends/request', { username: u.username }); toast(t('request_sent'), 'success'); run(); } catch (e) { toast(errText(e), 'error'); } }, 'primary small', 'userPlus')
          : u.relation === 'incoming' ? btn(t('accept'), async () => { try { await api('POST', `/api/friends/${u.relation_id}/accept`); run(); } catch (e) { toast(errText(e), 'error'); } }, 'primary small')
          : h('small', { class: 'muted' }, t('requested')))));
      if (r.spaces.length) drop.append(h('h5', null, t('spaces')), ...r.spaces.map((s) => h('div', { class: 'srow' }, avatar({ id: s.id, display_name: s.name, avatar_file: s.avatar_file }, 34, { group: true }), h('span', { class: 'mi-name' }, h('b', null, s.name)),
        s.joined ? btn(t('open'), () => { close(); input.value = ''; hooks.open(s.id); }, 'ghost small') : btn(t('join'), async () => { try { const j = await api('POST', `/api/conversations/${s.id}/join`); close(); input.value = ''; hooks.afterCreate(j.conv); } catch (e) { toast(errText(e), 'error'); } }, 'primary small'))));
      if (r.messages.length) drop.append(h('h5', null, t('messages')), messageResults(r.messages.slice(0, 6), (m) => { close(); input.value = ''; hooks.openAround(m.conv_id, m.id); }));
      if (!r.people.length && !r.spaces.length && !r.messages.length) drop.append(h('p', { class: 'muted pad' }, t('no_results')));
      drop.append(h('button', { class: 'adv', type: 'button', onclick: () => { close(); advancedSearchDialog({ q }); } }, icon('sliders', 16), t('advanced_search')));
      drop.hidden = false;
    } catch (e) { if (e.code !== 'rate_limited') close(); }
  };
  input.addEventListener('input', debounce(run, 250));
  input.addEventListener('focus', () => { if (drop.children.length && input.value.trim().length >= 2) drop.hidden = false; });
  input.addEventListener('keydown', (e) => { if (e.key === 'Escape') { close(); input.blur(); } });
  document.addEventListener('pointerdown', (e) => { if (!box.contains(e.target)) close(); });
  host.append(box);
  hooks.focusSearch = () => input.focus();
}
