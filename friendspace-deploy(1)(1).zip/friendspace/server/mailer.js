'use strict';
// Mail delivery. With RESEND_API_KEY set, mail goes out through the Resend HTTP API.
// Otherwise (development) the message is printed to the console and written to data/outbox/.
const fs = require('node:fs');
const path = require('node:path');

module.exports = function createMailer(config) {
  return async function sendMail({ to, subject, text }) {
    if (config.resendKey) {
      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: 'Bearer ' + config.resendKey, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from: config.mailFrom, to: [to], subject, text }),
      });
      if (!r.ok) throw new Error('mail provider error ' + r.status);
      return { delivered: true };
    }
    const dir = path.join(config.dataDir, 'outbox');
    fs.mkdirSync(dir, { recursive: true });
    const file = path.join(dir, Date.now() + '-' + to.replace(/[^a-z0-9@._-]/gi, '_') + '.txt');
    fs.writeFileSync(file, `To: ${to}\nSubject: ${subject}\n\n${text}\n`);
    if (!config.quiet) console.log(`[mail:dev] To: ${to} | ${subject}\n${text}\n(saved to ${file})`);
    return { delivered: false, file };
  };
};
