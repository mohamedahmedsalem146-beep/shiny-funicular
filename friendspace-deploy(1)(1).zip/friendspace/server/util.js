'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const scrypt = promisify(crypto.scrypt);

class HttpError extends Error {
  constructor(status, code, extra) { super(code); this.status = status; this.code = code; this.extra = extra; }
}

const sha256 = (s) => crypto.createHash('sha256').update(String(s)).digest('hex');
const randomToken = (n = 32) => crypto.randomBytes(n).toString('hex');
const now = () => Date.now();

async function hashPassword(pw) {
  const salt = crypto.randomBytes(16);
  const N = 16384;
  const key = await scrypt(pw, salt, 64, { N, r: 8, p: 1 });
  return `scrypt$${N}$${salt.toString('hex')}$${key.toString('hex')}`;
}
async function verifyPassword(pw, stored) {
  try {
    const [alg, N, salt, hash] = String(stored).split('$');
    if (alg !== 'scrypt') return false;
    const h = Buffer.from(hash, 'hex');
    const key = await scrypt(pw, Buffer.from(salt, 'hex'), h.length, { N: +N, r: 8, p: 1 });
    return crypto.timingSafeEqual(h, key);
  } catch { return false; }
}

class RateLimiter {
  constructor() { this.m = new Map(); this.t = setInterval(() => this.gc(), 60000); this.t.unref(); }
  /** returns true if allowed */
  hit(key, limit, windowMs) {
    const t = now();
    let e = this.m.get(key);
    if (!e || e.reset < t) { e = { n: 0, reset: t + windowMs }; this.m.set(key, e); }
    e.n++;
    return e.n <= limit;
  }
  count(key) { const e = this.m.get(key); return e && e.reset > now() ? e.n : 0; }
  clear(key) { this.m.delete(key); }
  gc() { const t = now(); for (const [k, e] of this.m) if (e.reset < t) this.m.delete(k); }
}

function parseCookies(h) {
  const out = {};
  if (!h) return out;
  for (const part of h.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > limit) { reject(new HttpError(413, 'too_large')); req.destroy(); return; }
      chunks.push(c);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJson(req, limit = 64 * 1024) {
  const buf = await readBody(req, limit);
  if (!buf.length) return {};
  try { const v = JSON.parse(buf.toString('utf8')); return v && typeof v === 'object' ? v : {}; }
  catch { throw new HttpError(400, 'bad_json'); }
}

function escapeLike(s) { return String(s).replace(/[\\%_]/g, (c) => '\\' + c); }
const str = (v, max) => (typeof v === 'string' ? v.trim().slice(0, max) : '');
const int = (v) => { const n = Number(v); return Number.isSafeInteger(n) ? n : null; };

module.exports = { HttpError, sha256, randomToken, now, hashPassword, verifyPassword, RateLimiter, parseCookies, readBody, readJson, escapeLike, str, int };
