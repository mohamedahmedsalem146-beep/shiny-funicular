'use strict';
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { open } = require('./db');
const createRealtime = require('./realtime');
const createMailer = require('./mailer');
const createApp = require('./routes');
const ws = require('./ws');
const { HttpError } = require('./util');
const moderation = require('./moderation');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json', '.webmanifest': 'application/manifest+json' };

function loadConfig(o = {}) {
  const e = process.env;
  const port = Number(o.port ?? e.PORT ?? 3000);
  const dataDir = path.resolve(o.dataDir ?? e.DATA_DIR ?? path.join(__dirname, '..', 'data'));
  return {
    port, host: o.host ?? e.HOST ?? '0.0.0.0', dataDir,
    publicUrl: (o.publicUrl ?? e.PUBLIC_URL ?? `http://localhost:${port}`).replace(/\/+$/, ''),
    trustProxy: (o.trustProxy ?? e.TRUST_PROXY) === '1' || o.trustProxy === true,
    cookieSecure: o.cookieSecure ?? e.COOKIE_SECURE ?? 'auto',
    sessionDays: Number(e.SESSION_DAYS || 30),
    maxUpload: Number(e.MAX_UPLOAD_MB || 10) * 1024 * 1024,
    maxAvatar: 2 * 1024 * 1024,
    registrationOpen: (o.registrationOpen ?? e.REGISTRATION_OPEN ?? '1') !== '0',
    adminEmail: (e.ADMIN_EMAIL || '').toLowerCase(),
    corsOrigins: (o.corsOrigins ?? e.CORS_ORIGINS ?? '').split(',').map((x) => x.trim()).filter(Boolean),
    allowedOrigins: (e.ALLOWED_ORIGINS || '').split(',').map((s) => s.trim()).filter(Boolean),
    meetingBase: o.meetingBase ?? (e.MEETING_BASE_URL === undefined ? 'https://meet.jit.si' : e.MEETING_BASE_URL),
    resendKey: e.RESEND_API_KEY || '', mailFrom: e.MAIL_FROM || 'FriendSpace <onboarding@resend.dev>',
    moderation: o.moderation ?? e.MODERATION ?? 'suspend', suspendDays: Number(o.suspendDays ?? e.SUSPEND_DAYS ?? 7),
    quiet: !!o.quiet,
  };
}

function start(overrides = {}) {
  const config = loadConfig(overrides);
  const db = open(path.join(config.dataDir, 'friendspace.db'));
  moderation.loadExtra(path.join(config.dataDir, 'moderation-extra.txt'));
  const rt = createRealtime(db);
  const mailer = createMailer(config);
  const app = createApp({ db, rt, config, mailer });
  const pubDir = path.join(__dirname, '..', 'public');

  const SEC = {
    'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'DENY', 'Referrer-Policy': 'no-referrer',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' ws: wss:; frame-ancestors 'none'; base-uri 'none'; form-action 'self'; object-src 'none'",
  };
  if (config.publicUrl.startsWith('https')) SEC['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';

  function serveStatic(req, res, pathname) {
    let rel = decodeURIComponent(pathname);
    if (rel === '/' || !path.extname(rel)) rel = '/index.html';
    const file = path.normalize(path.join(pubDir, rel));
    if (!file.startsWith(pubDir + path.sep) || !fs.existsSync(file) || !fs.statSync(file).isFile()) { res.writeHead(404, SEC); res.end('Not found'); return; }
    const ext = path.extname(file);
    const h = { ...SEC, 'Content-Type': MIME[ext] || 'application/octet-stream', 'Cache-Control': ext === '.html' ? 'no-cache' : 'no-cache' };
    res.writeHead(200, h);
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  }

  // Cross-origin API access for the single-file client (FriendSpace.html) — token auth only, never cookies.
  const corsOk = (origin) => !!origin && (config.corsOrigins.includes('*') || config.corsOrigins.includes(origin));
  const server = http.createServer(async (req, res) => {
    for (const [k, v] of Object.entries(SEC)) res.setHeader(k, v);
    try {
      const url = new URL(req.url, 'http://x');
      const origin = req.headers.origin;
      if (origin && url.pathname.startsWith('/api/') && corsOk(origin)) {
        res.setHeader('Access-Control-Allow-Origin', origin === 'null' ? '*' : origin); res.setHeader('Vary', 'Origin');
        res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-Requested-With, X-Token-Auth, Authorization'); res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, PUT, DELETE, OPTIONS');
        if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }
      }
      if (url.pathname.startsWith('/api/')) await app.handle(req, res, url);
      else if (req.method === 'GET' || req.method === 'HEAD') serveStatic(req, res, url.pathname);
      else { res.writeHead(405); res.end(); }
    } catch (e) {
      if (res.headersSent) { res.destroy(); return; }
      const status = e instanceof HttpError ? e.status : 500;
      if (!(e instanceof HttpError)) console.error(e);
      res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(JSON.stringify({ error: e instanceof HttpError ? e.code : 'server_error', ...(e.extra || {}) }));
    }
  });

  server.on('upgrade', (req, socket) => {
    try {
      const url = new URL(req.url, 'http://x');
      if (url.pathname !== '/ws' || !(app.originOk(req) || (url.searchParams.get('token') && corsOk(req.headers.origin)))) { socket.end('HTTP/1.1 403 Forbidden\r\n\r\n'); return; }
      const a = app.authenticate(req);
      if (!a || a.suspended) { socket.end('HTTP/1.1 401 Unauthorized\r\n\r\n'); return; }
      const conn = ws.accept(req, socket);
      if (conn) rt.attach(conn, a.user, a.sessionId);
    } catch { socket.destroy(); }
  });

  return new Promise((resolve) => {
    server.listen(config.port, config.host, () => {
      const port = server.address().port;
      if (!config.quiet) console.log(`FriendSpace listening on port ${port}  (public URL: ${config.publicUrl}, data: ${config.dataDir})`);
      resolve({ server, port, config, db, rt, close: () => new Promise((r) => { rt.stop(); server.closeAllConnections?.(); server.close(() => { db.close(); r(); }); }) });
    });
  });
}

module.exports = { start };
if (require.main === module) {
  start().then((app) => {
    const c = app.config;
    if (process.env.NODE_ENV === 'production') {
      if (!process.env.PUBLIC_URL) console.warn('[warn] PUBLIC_URL is not set: password-reset links will point to ' + c.publicUrl);
      else if (!c.publicUrl.startsWith('https://')) console.warn('[warn] PUBLIC_URL is not https — serve FriendSpace behind an HTTPS reverse proxy.');
      if (!c.trustProxy) console.warn('[warn] TRUST_PROXY is not 1: behind a proxy every client shares one IP for rate limits.');
      if (!c.resendKey) console.warn('[warn] RESEND_API_KEY is not set: password-reset e-mails are written to ' + c.dataDir + '/outbox instead of being sent.');
    }
    let closing = false;
    const stop = () => { if (closing) return; closing = true; console.log('Shutting down…'); app.close().then(() => process.exit(0)); setTimeout(() => process.exit(0), 5000).unref(); };
    process.on('SIGTERM', stop); process.on('SIGINT', stop);
  });
}
